#SMARTAPI-R
SMARTAPI-R is a R library for dealing AMX,that is a set of REST-like HTTP APIs that expose many capabilities required to build stock market investment and trading platforms. It lets you execute orders in real time.

##Installation

To use this package, unzip the file with ".zip" extention to the path where R libraries are installed.
File_path: smartapi-r\package\smartapi_0.1.0.zip
Unzip the file in the below location:
Path: C:\Program Files\R\R-4.0.3\library 
(Note:The above path is only for reference,it can differ from user to user)
##Usage

For details on the use of the package and other important points, please see the package vignette.
